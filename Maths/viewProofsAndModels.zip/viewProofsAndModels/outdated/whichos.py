#!/usr/bin/python

from os import *


sys=uname()
print sys[0]
